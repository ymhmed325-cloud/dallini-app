import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const apiUrl = String.fromEnvironment(
  'API_URL',
  defaultValue: 'https://dallinibackend-dtayttcp.b4a.run',
);

void main() {
  runApp(const DalliniApp());
}

class DalliniApp extends StatelessWidget {
  const DalliniApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دلّيني',
      locale: const Locale('ar'),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF123B68),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
      ),
      home: const AppRoot(),
    );
  }
}

class AppRoot extends StatefulWidget {
  const AppRoot({super.key});
  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  bool loading = true;
  bool loggedIn = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      loggedIn = p.getBool('logged_in') ?? false;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(
          child: Text(
            'دلّيني',
            style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900),
          ),
        ),
      );
    }
    return loggedIn
        ? const MainShell()
        : LoginScreen(onLoggedIn: _load);
  }
}

class LoginScreen extends StatefulWidget {
  final VoidCallback onLoggedIn;
  const LoginScreen({super.key, required this.onLoggedIn});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final otp = TextEditingController();
  final name = TextEditingController();
  bool sent = false;
  bool busy = false;

  Future<void> login() async {
    if (phone.text.trim().length < 9) {
      _msg('أدخل رقم هاتف صحيح');
      return;
    }
    if (!sent) {
      setState(() => sent = true);
      _msg('تم إرسال رمز التحقق. في وضع الاختبار استخدم 123456');
      return;
    }
    if (otp.text.trim() != '123456') {
      _msg('رمز التحقق غير صحيح');
      return;
    }

    setState(() => busy = true);
    final enteredPhone = phone.text.trim();
    final enteredName = name.text.trim().isEmpty ? 'مستخدم دلّيني' : name.text.trim();

    // وضع الاختبار: تسجيل الدخول محلي بالكامل.
    // لا ننتظر Backend ولا نطلب منه المصادقة، حتى لا يمنع انتهاء الخادم المؤقت الدخول.
    try {
      await _saveLocalLogin(enteredPhone, enteredName);
      if (!mounted) return;
      setState(() => busy = false);
      _msg('تم الدخول بنجاح');
      widget.onLoggedIn();
    } catch (_) {
      if (mounted) {
        setState(() => busy = false);
        _msg('تعذر حفظ بيانات الدخول');
      }
    }
  }

  Future<void> _saveLocalLogin(String userPhone, String userName) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('logged_in', true);
    await p.setString('phone', userPhone);
    await p.setString('name', userName);
    await p.setString('auth_mode', 'demo');
  }

  void _msg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 50),
                const Text('دلّيني',
                    style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF123B68))),
                const SizedBox(height: 8),
                const Text('عندك مشكلة؟ دلّيني على الحل.',
                    style: TextStyle(fontSize: 17)),
                const SizedBox(height: 45),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const Align(
                          alignment: Alignment.centerRight,
                          child: Text('تسجيل الدخول',
                              style: TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.w800)),
                        ),
                        const SizedBox(height: 18),
                        TextField(
                          controller: phone,
                          keyboardType: TextInputType.phone,
                          decoration: const InputDecoration(
                            labelText: 'رقم الهاتف',
                            hintText: '07XXXXXXXXX',
                            prefixText: '+964 ',
                            border: OutlineInputBorder(),
                          ),
                        ),
                        if (sent) ...[
                          const SizedBox(height: 12),
                          TextField(
                            controller: otp,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'رمز التحقق',
                              hintText: '123456',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: name,
                            decoration: const InputDecoration(
                              labelText: 'الاسم',
                              hintText: 'اكتب اسمك',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ],
                        const SizedBox(height: 18),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: busy ? null : login,
                            child: Padding(
                              padding: const EdgeInsets.all(14),
                              child: Text(
                                  busy ? 'جاري الدخول...' : sent ? 'دخول' : 'إرسال رمز التحقق'),
                            ),
                          ),
                        ),
                        if (sent)
                          TextButton(
                            onPressed: () => setState(() => sent = false),
                            child: const Text('تغيير رقم الهاتف'),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [
    HomePage(),
    OrdersPage(),
    NewRequestPage(),
    MessagesPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) => setState(() => index = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'طلباتي'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'طلب جديد'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'المحادثات'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final cats = [
      ['⚡', 'كهرباء'],
      ['💧', 'سباكة'],
      ['❄️', 'تكييف'],
      ['🔧', 'صيانة أجهزة'],
      ['🧹', 'تنظيف'],
      ['🚗', 'سيارات'],
    ];
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 25),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0D2B50), Color(0xFF1D558B)],
                ),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('دلّيني',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900)),
                  SizedBox(height: 4),
                  Text('عندك مشكلة؟ دلّيني على الحل.',
                      style: TextStyle(color: Colors.white70, fontSize: 15)),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(Icons.location_on, color: Colors.white, size: 19),
                      SizedBox(width: 5),
                      Text('بغداد', style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(18),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                const Text('شنو تحتاج؟',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: cats.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 1.05,
                  ),
                  itemBuilder: (_, i) => Card(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => NewRequestPage(initialCategory: cats[i][1]),
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(cats[i][0], style: const TextStyle(fontSize: 28)),
                          const SizedBox(height: 5),
                          Text(cats[i][1],
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                const Text('خدمات قريبة منك',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                const ProviderCard(),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class ProviderCard extends StatelessWidget {
  const ProviderCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Row(
          children: const [
            CircleAvatar(radius: 27, child: Text('👨‍🔧', style: TextStyle(fontSize: 25))),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('أحمد علي', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  Text('✓ مقدم خدمة موثّق', style: TextStyle(color: Colors.green, fontSize: 12)),
                  SizedBox(height: 4),
                  Text('فني تكييف • 2.4 كم • متاح الآن',
                      style: TextStyle(color: Colors.grey, fontSize: 12)),
                  Text('★ 4.8 • 312 تقييم',
                      style: TextStyle(color: Color(0xFFB77900), fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NewRequestPage extends StatefulWidget {
  final String? initialCategory;
  const NewRequestPage({super.key, this.initialCategory});
  @override
  State<NewRequestPage> createState() => _NewRequestPageState();
}

class _NewRequestPageState extends State<NewRequestPage> {
  late String category;
  final desc = TextEditingController();
  bool busy = false;

  final categories = const ['كهرباء', 'سباكة', 'تكييف', 'صيانة أجهزة', 'تنظيف', 'سيارات'];

  @override
  void initState() {
    super.initState();
    category = widget.initialCategory ?? 'كهرباء';
  }

  Future<void> submit() async {
    if (desc.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب المشكلة أولاً')));
      return;
    }
    setState(() => busy = true);
    try {
      final r = await http.post(
        Uri.parse('$apiUrl/api/requests'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'category': category,
          'description': desc.text.trim(),
          'address': 'بغداد',
        }),
      );
      if (r.statusCode >= 200 && r.statusCode < 300) {
        if (!mounted) return;
        await showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('تم إرسال الطلب ✓'),
            content: const Text('بدأنا البحث عن مقدم خدمة مناسب لمشكلتك.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسنًا')),
            ],
          ),
        );
        desc.clear();
      } else {
        throw Exception();
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر إرسال الطلب. تحقق من الاتصال بالخادم.')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('شنو المشكلة؟',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          const SizedBox(height: 7),
          const Text('اكتبها بطريقتك، مو لازم تعرف اسم الخدمة.',
              style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 18),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'الفئة', border: OutlineInputBorder()),
            items: categories.map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
            onChanged: (x) => setState(() => category = x!),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: desc,
            maxLines: 6,
            decoration: const InputDecoration(
              labelText: 'وصف المشكلة',
              hintText: 'مثال: المكيف يشتغل بس الهوا حار...',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: OutlinedButton.icon(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('التسجيل الصوتي سيضاف في المرحلة التالية'))),
                icon: const Icon(Icons.mic), label: const Text('احچي'),
              )),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الكاميرا ستضاف في المرحلة التالية'))),
                icon: const Icon(Icons.camera_alt_outlined), label: const Text('صوّر'),
              )),
            ],
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: busy ? null : submit,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(busy ? 'جاري إرسال الطلب...' : 'دلّيني على الحل'),
            ),
          ),
        ],
      ),
    );
  }
}

class OrdersPage extends StatefulWidget {
  const OrdersPage({super.key});
  @override
  State<OrdersPage> createState() => _OrdersPageState();
}
class _OrdersPageState extends State<OrdersPage> {
  bool loading = true;
  List orders = [];

  @override
  void initState() {
    super.initState();
    load();
  }
  Future<void> load() async {
    try {
      final r = await http.get(Uri.parse('$apiUrl/api/requests/mine'));
      if (r.statusCode == 200) orders = jsonDecode(r.body) as List;
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('طلباتي', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            if (loading) const Center(child: CircularProgressIndicator()),
            if (!loading && orders.isEmpty)
              const Card(child: Padding(
                padding: EdgeInsets.all(20),
                child: Text('لا توجد طلبات حالياً. عند إرسال طلب سيظهر هنا.'),
              )),
            ...orders.map((o) => Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.build_outlined)),
                title: Text((o['category'] ?? 'خدمة').toString()),
                subtitle: Text((o['description'] ?? '').toString()),
                trailing: Text((o['status'] ?? '').toString()),
              ),
            )),
          ],
        ),
      ),
    );
  }
}

class MessagesPage extends StatelessWidget {
  const MessagesPage({super.key});
  @override
  Widget build(BuildContext context) => const SafeArea(
    child: Center(child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.chat_bubble_outline, size: 55, color: Color(0xFF123B68)),
        SizedBox(height: 12),
        Text('المحادثات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        SizedBox(height: 6),
        Text('ستظهر محادثاتك مع مقدمي الخدمة هنا.'),
      ],
    )),
  );
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}
class _ProfilePageState extends State<ProfilePage> {
  String name = 'مستخدم دلّيني';
  String phone = '';

  @override
  void initState() {
    super.initState();
    load();
  }
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      name = p.getString('name') ?? 'مستخدم دلّيني';
      phone = p.getString('phone') ?? '';
    });
  }

  Future<void> editName() async {
    final c = TextEditingController(text: name);
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تعديل الاسم'),
        content: TextField(controller: c, decoration: const InputDecoration(labelText: 'الاسم')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
    if (value != null && value.isNotEmpty) {
      final p = await SharedPreferences.getInstance();
      await p.setString('name', value);
      setState(() => name = value);
    }
  }

  Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('logged_in', false);
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => LoginScreen(onLoggedIn: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const MainShell())))),
      (_) => false,
    );
  }

  void soon(String title) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: const Text('هذه الميزة ضمن المرحلة القادمة من تطوير دلّيني.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسنًا'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('حسابي', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const CircleAvatar(radius: 27, child: Icon(Icons.person)),
              title: Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(phone.isEmpty ? 'رقم الهاتف غير محفوظ' : '+964 $phone'),
              trailing: IconButton(onPressed: editName, icon: const Icon(Icons.edit_outlined)),
            ),
          ),
          const SizedBox(height: 8),
          _row(Icons.receipt_long_outlined, 'طلباتي', () => Navigator.of(context).maybePop()),
          _row(Icons.location_on_outlined, 'عناويني', () => soon('عناويني')),
          _row(Icons.favorite_border, 'مقدمو الخدمة المفضلون', () => soon('المفضلون')),
          _row(Icons.notifications_none, 'الإشعارات', () => soon('الإشعارات')),
          _row(Icons.settings_outlined, 'الإعدادات', () => soon('الإعدادات')),
          _row(Icons.security_outlined, 'الأمان والخصوصية', () => soon('الأمان والخصوصية')),
          _row(Icons.help_outline, 'المساعدة', () => soon('المساعدة')),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: logout,
            icon: const Icon(Icons.logout, color: Colors.red),
            label: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _row(IconData icon, String title, VoidCallback onTap) {
    return Card(
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: const Color(0xFF123B68)),
        title: Text(title),
        trailing: const Icon(Icons.chevron_left),
      ),
    );
  }
}
